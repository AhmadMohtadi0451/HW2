

// 1=
//Nan
//122
//5
//4
//true
//true
//false
//false
// 2=



// 3 =
function digits_count(n) {
    let count = 0;
    if (n >= 1) ++count;
    while( n / 10>=1) {
        n /= 10;
        ++count;
    }

    return count;
}
console.log(digits_count(12344));

// 4 =
const number1 = 100
const number2 = 20
for( let i = 2 ;i <= number1 && i <= number2 ; i++) {
    if( number1 % i == 0 && number2 % i == 0){
       console.log(i);
    }
}


// 2 =

let a = 5
let b = 3
let c = 9
if ( a + b > c && b + c > a && c + a > b){
    console.log("yes");
}
else{
    console.log("no");
}











